import { useRef } from "react";

function NoteAddForm({ addNote }) {
    const notesInput = useRef();
    const notesTypeInput = useRef();

    return (
        <fieldset>
            <legend><b>Noten Hinzufügen</b></legend>
            <form onSubmit={e => {
                e.preventDefault()
                addNote([parseFloat(notesInput.current?.value), notesTypeInput.current?.value == "s"])
            }}>
                <select ref={notesTypeInput}>
                    <option value="m">Kleine Note (x1)</option>
                    <option value="s">Große Note (x2)</option>
                </select>
                <select ref={notesInput}>
                    <option value={1}>{1}</option>
                    <option value={1.5}>{1.5}</option>
                    <option value={2}>{2}</option>
                    <option value={2.5}>{2.5}</option>
                    <option value={3}>{3}</option>
                    <option value={3.5}>{3.5}</option>
                    <option value={4}>{4}</option>
                    <option value={4.5}>{4.5}</option>
                    <option value={5}>{5}</option>
                    <option value={5.5}>{5.5}</option>
                    <option value={6}>{6}</option>
                </select>
                <button>
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M440-440H200v-80h240v-240h80v240h240v80H520v240h-80v-240Z" /></svg>Hinzufügen
                </button>
            </form>
        </fieldset>
    )
}

export default NoteAddForm