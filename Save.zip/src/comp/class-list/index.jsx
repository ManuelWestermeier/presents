import { Link } from "react-router-dom"
import "./index.css"

function ClassList({ classes = {}, setClasses }) {
    return (
        <div className="class-list">
            {Object.keys(classes).map(key => {
                return <Link key={key} to={`/class/${key}`} className="class">
                    <span>{classes[key].name}</span>
                    <button type="button" onClick={e => {
                        //delete
                        e.preventDefault()
                        if (!confirm(`Wollen sie die Klasse ${classes[key].name} wirklich löschen?`))
                            return
                        setClasses(old => {
                            delete old[key]
                            return { ...old }
                        })
                    }}>
                        <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" /></svg>
                    </button>
                </Link>
            })}
        </div>
    )
}

export default ClassList